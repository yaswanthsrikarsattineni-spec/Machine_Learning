"""Fast contract tests; they never alter raw data or train a neural network."""
from pathlib import Path

import numpy as np
import pandas as pd

from src.data_loader import anomaly_metadata, baseline_metadata, make_baseline_split
from src.preprocessing import preprocess_radio
from src.windowing import create_windows

ROOT = Path(__file__).resolve().parents[1]
FEATURES = ["l1_pusch_count", "l1_avg_pusch_count"]


def test_dataset_counts_and_recording_split() -> None:
    split = make_baseline_split(baseline_metadata(ROOT / "data/raw/Baseline"), 42)
    assert split.split.value_counts().to_dict() == {"train": 40, "normal_test": 9, "validation": 8}
    assert split.recording.nunique() == 57
    assert len(anomaly_metadata(ROOT / "data/raw/Anomaly")) == 16


def test_preprocessing_excludes_long_gap_and_windows_stay_segment_local() -> None:
    frame = pd.DataFrame({"timestamp": ["2024-01-01 00:00:00", "2024-01-01 00:00:00.15", "2024-01-01 00:00:00.30", "2024-01-01 00:00:00.45", "2024-01-01 00:00:02.00"], FEATURES[0]: [1, np.nan, 3, 4, 5], FEATURES[1]: [1, np.nan, 3, 4, 5]})
    result = preprocess_radio(frame, FEATURES, {"max_interpolation_gap_rows": 1, "major_timestamp_gap_seconds": 1.0}, "unit", "1UE", False)
    windows, meta = create_windows(result.segments, FEATURES, 2, 1, "unit", "1UE", False)
    assert len(windows) == len(meta)
    assert all(meta.groupby("segment_id").size() >= 1)
