"""Non-misleading figures saved reproducibly for the research report."""
from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


def save_training_plot(history: pd.DataFrame, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 4)); ax.plot(history.epoch, history.loss, label="Training"); ax.plot(history.epoch, history.val_loss, label="Validation"); ax.set(xlabel="Epoch", ylabel="MSE reconstruction loss", title="LSTM Autoencoder Training History"); ax.legend(); fig.tight_layout(); fig.savefig(out, dpi=180); plt.close(fig)


def save_error_plot(predictions: pd.DataFrame, threshold: float, title: str, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(8, 4)); sns.histplot(predictions.reconstruction_error, bins=50, ax=ax); ax.axvline(threshold, color="crimson", label="Threshold"); ax.set(title=title, xlabel="Window reconstruction MSE"); ax.legend(); fig.tight_layout(); fig.savefig(out, dpi=180); plt.close(fig)


def save_timeline(predictions: pd.DataFrame, out: Path) -> None:
    if predictions.empty: return
    frame = predictions[predictions.recording == predictions.recording.iloc[0]]
    fig, ax = plt.subplots(figsize=(10, 4)); ax.plot(frame.start_time, frame.reconstruction_error, lw=1, label="Reconstruction error"); ax.scatter(frame.loc[frame.predicted_anomaly.eq(1), "start_time"], frame.loc[frame.predicted_anomaly.eq(1), "reconstruction_error"], s=8, label="Predicted anomaly"); known = frame.ground_truth_known; ax.scatter(frame.loc[known & frame.ground_truth.eq(1), "start_time"], frame.loc[known & frame.ground_truth.eq(1), "reconstruction_error"], s=8, marker="x", label="Ground truth anomaly"); ax.set(xlabel="Elapsed seconds", ylabel="MSE", title=f"Anomaly timeline: {frame.recording.iloc[0]}"); ax.legend(); fig.tight_layout(); fig.savefig(out, dpi=180); plt.close(fig)
