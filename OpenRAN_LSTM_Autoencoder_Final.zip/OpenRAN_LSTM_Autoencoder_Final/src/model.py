"""Keras LSTM autoencoder construction and reconstruction scoring."""
from __future__ import annotations

import numpy as np
import tensorflow as tf


def build_autoencoder(window_size: int, feature_count: int, config: dict) -> tf.keras.Model:
    encoder, latent = config["encoder_units"]
    inputs = tf.keras.Input(shape=(window_size, feature_count), name="radio_window")
    x = tf.keras.layers.LSTM(encoder, return_sequences=True)(inputs)
    x = tf.keras.layers.LSTM(latent, return_sequences=False)(x)
    x = tf.keras.layers.RepeatVector(window_size)(x)
    x = tf.keras.layers.LSTM(latent, return_sequences=True)(x)
    x = tf.keras.layers.LSTM(encoder, return_sequences=True)(x)
    outputs = tf.keras.layers.TimeDistributed(tf.keras.layers.Dense(feature_count))(x)
    model = tf.keras.Model(inputs, outputs, name="lstm_autoencoder")
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=config["learning_rate"]), loss="mse")
    return model


def reconstruction_errors(model: tf.keras.Model, windows: np.ndarray, batch_size: int) -> np.ndarray:
    if not len(windows):
        return np.array([], dtype=float)
    reconstructed = model.predict(windows, batch_size=batch_size, verbose=0)
    return np.mean(np.square(windows - reconstructed), axis=(1, 2))
