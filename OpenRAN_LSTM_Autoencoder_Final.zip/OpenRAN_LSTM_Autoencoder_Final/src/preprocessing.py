"""Timestamp-aware, segment-preserving radio-recording preprocessing."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)


@dataclass
class ProcessedRecording:
    segments: list[pd.DataFrame]
    statistics: dict[str, Any]


def _parse_time(series: pd.Series, duration_style: bool) -> pd.Series:
    raw = series.astype(str).str.strip()
    if duration_style:
        # RADIO/radio.csv uses MM:SS.s elapsed times, not calendar datetimes.
        return pd.to_timedelta("00:" + raw, errors="coerce").dt.total_seconds()
    parsed = pd.to_datetime(raw, errors="coerce")
    return parsed.astype("int64") / 1_000_000_000


def preprocess_radio(frame: pd.DataFrame, features: list[str], settings: dict[str, Any], recording: str, scenario: str, has_labels: bool) -> ProcessedRecording:
    required = ["timestamp", *features] + (["anomaly"] if has_labels else [])
    missing = sorted(set(required) - set(frame.columns))
    if missing:
        raise ValueError(f"{recording}: missing required columns {missing}")
    data = frame[required].copy()
    duration_style = scenario == "RADIO" and data.timestamp.astype(str).str.match(r"^\d{1,2}:\d{2}(?:\.\d+)?$").all()
    data["time_seconds"] = _parse_time(data.timestamp, duration_style)
    invalid_timestamps = int(data.time_seconds.isna().sum())
    data = data.dropna(subset=["time_seconds"])
    # Absolute timestamps can be ordered chronologically. Duration-style timestamps
    # must retain acquisition order so rollovers/non-positive jumps create segments.
    if not duration_style:
        data = data.sort_values("time_seconds", kind="stable")
    for feature in features:
        data[feature] = pd.to_numeric(data[feature], errors="coerce")
    if has_labels:
        data["anomaly"] = pd.to_numeric(data["anomaly"], errors="coerce")
    differences = data.time_seconds.diff()
    gaps = differences.gt(settings["major_timestamp_gap_seconds"])
    if duration_style:
        gaps |= differences.le(0)  # includes the documented 59:59.9 -> 00:00.1 rollover
    gaps = gaps.fillna(False)
    initial_chunks = [chunk.copy() for _, chunk in data.groupby(gaps.cumsum(), sort=False)]
    segments: list[pd.DataFrame] = []
    short_rows = long_rows = residual_nan_rows = duplicate_rows = 0
    for chunk in initial_chunks:
        duplicate_rows_chunk = int(chunk.time_seconds.duplicated(keep="first").sum())
        if duplicate_rows_chunk:
            chunk = chunk.drop_duplicates("time_seconds", keep="first")
        duplicate_rows += duplicate_rows_chunk
        missing_rows = chunk[features].isna().any(axis=1)
        blocks = missing_rows.ne(missing_rows.shift(fill_value=False)).cumsum()
        long_mask = pd.Series(False, index=chunk.index)
        for _, block in missing_rows.groupby(blocks):
            if bool(block.iloc[0]):
                if len(block) <= settings["max_interpolation_gap_rows"]:
                    short_rows += len(block)
                else:
                    long_rows += len(block)
                    long_mask.loc[block.index] = True
        # Time-aware interpolation only for short interior gaps; long rows are excluded first.
        usable = chunk.loc[~long_mask].copy().set_index("time_seconds", drop=False)
        usable[features] = usable[features].interpolate(method="index", limit=settings["max_interpolation_gap_rows"], limit_area="inside")
        remaining = usable[features].isna().any(axis=1)
        residual_nan_rows += int(remaining.sum())
        usable = usable.loc[~remaining].reset_index(drop=True)
        # Removing a long/residual gap creates distinct continuous segments.
        split = usable.time_seconds.diff().gt(settings["major_timestamp_gap_seconds"]).fillna(False)
        for _, segment in usable.groupby(split.cumsum(), sort=False):
            if not segment.empty:
                segments.append(segment.reset_index(drop=True))
    stats = {"recording": recording, "scenario": scenario, "input_rows": len(frame), "output_rows": sum(map(len, segments)), "segments": len(segments), "duration_timestamp": duration_style, "invalid_timestamps": invalid_timestamps, "duplicate_timestamps_removed": duplicate_rows, "major_timestamp_gaps": max(0, len(initial_chunks) - 1), "short_gap_rows_interpolated": short_rows, "long_gap_rows_excluded": long_rows, "residual_nan_rows_excluded": residual_nan_rows, "missing_anomaly_labels": int(data.anomaly.isna().sum()) if has_labels else 0}
    return ProcessedRecording(segments=segments, statistics=stats)
