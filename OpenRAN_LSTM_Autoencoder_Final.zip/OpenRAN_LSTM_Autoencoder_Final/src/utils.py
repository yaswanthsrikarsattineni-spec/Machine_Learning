"""Configuration, logging, reproducibility, and filesystem helpers."""
from __future__ import annotations

import json
import logging
import os
import random
from pathlib import Path
from typing import Any

import numpy as np
import yaml


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    path = Path(path) if path else project_root() / "config" / "config.yaml"
    with path.open(encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    config["root"] = project_root()
    for key, value in config["paths"].items():
        config["paths"][key] = config["root"] / value
    return config


def ensure_output_dirs(config: dict[str, Any]) -> None:
    for key in ("processed_dir", "models_dir", "results_dir"):
        config["paths"][key].mkdir(parents=True, exist_ok=True)
    for folder in ("tables", "figures", "predictions"):
        (config["paths"]["results_dir"] / folder).mkdir(parents=True, exist_ok=True)


def set_reproducibility(seed: int) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    os.environ.setdefault("TF_DETERMINISTIC_OPS", "1")
    random.seed(seed)
    np.random.seed(seed)
    import tensorflow as tf
    tf.keras.utils.set_random_seed(seed)
    try:
        tf.config.experimental.enable_op_determinism()
    except Exception:  # platform-dependent; seed remains set
        pass


def configure_logging() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def save_json(value: Any, path: Path) -> None:
    def default(obj: Any) -> Any:
        if isinstance(obj, (np.integer, np.floating)):
            return obj.item()
        if isinstance(obj, Path):
            return str(obj)
        raise TypeError(f"Cannot serialise {type(obj).__name__}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, default=default), encoding="utf-8")
