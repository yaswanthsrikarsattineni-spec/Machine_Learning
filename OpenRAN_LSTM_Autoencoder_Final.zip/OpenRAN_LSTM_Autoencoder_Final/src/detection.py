"""Window prediction and recording/segment-local event grouping."""
from __future__ import annotations

import numpy as np
import pandas as pd


def attach_predictions(metadata: pd.DataFrame, errors: np.ndarray, threshold: float) -> pd.DataFrame:
    result = metadata.copy()
    result["reconstruction_error"] = errors
    result["predicted_anomaly"] = (result.reconstruction_error > threshold).astype(int)
    return result


def group_events(predictions: pd.DataFrame, source: str) -> pd.DataFrame:
    events = []
    for (recording, segment_id), frame in predictions.groupby(["recording", "segment_id"], sort=False):
        frame = frame.reset_index(drop=True)
        groups = frame.predicted_anomaly.ne(frame.predicted_anomaly.shift(fill_value=0)).cumsum()
        for _, block in frame.groupby(groups):
            if not int(block.predicted_anomaly.iloc[0]):
                continue
            known_truth = block.ground_truth_known.all()
            events.append({"source": source, "recording": recording, "scenario": block.scenario.iloc[0], "segment_id": segment_id, "start_time": block.start_time.iloc[0], "end_time": block.end_time.iloc[-1], "duration_seconds": block.end_time.iloc[-1] - block.start_time.iloc[0], "anomalous_windows": len(block), "mean_reconstruction_error": block.reconstruction_error.mean(), "max_reconstruction_error": block.reconstruction_error.max(), "ground_truth_event": int(block.ground_truth.mean() >= 0.5) if known_truth else np.nan, "ground_truth_known": bool(known_truth)})
    return pd.DataFrame(events)


def label_persistence(events: pd.DataFrame, threshold_windows: int) -> pd.DataFrame:
    result = events.copy()
    if result.empty:
        result["predicted_event_type"] = pd.Series(dtype=str)
    else:
        result["predicted_event_type"] = np.where(result.anomalous_windows >= threshold_windows, "persistent", "transient")
    return result
