"""Validation-only reconstruction-error threshold selection."""
from __future__ import annotations

import numpy as np
import pandas as pd


def analyze_thresholds(validation_errors: np.ndarray, candidates: list[int], normal_test_errors: np.ndarray | None = None) -> tuple[pd.DataFrame, float]:
    if not len(validation_errors):
        raise ValueError("Cannot select a threshold without validation errors")
    rows = []
    for percentile in candidates:
        threshold = float(np.percentile(validation_errors, percentile))
        row = {"percentile": percentile, "threshold": threshold, "validation_false_positive_rate": float(np.mean(validation_errors > threshold))}
        if normal_test_errors is not None and len(normal_test_errors):
            row["normal_test_false_alarm_rate"] = float(np.mean(normal_test_errors > threshold))
        rows.append(row)
    table = pd.DataFrame(rows)
    return table, float(table.iloc[0].threshold)
