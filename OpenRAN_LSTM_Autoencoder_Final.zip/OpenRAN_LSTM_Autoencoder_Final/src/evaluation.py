"""Window and event metrics with explicit exclusion of unknown labels."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, average_precision_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score


def detection_metrics(predictions: pd.DataFrame, name: str) -> dict:
    known = predictions[predictions.ground_truth_known].copy()
    if known.empty:
        return {"dataset": name, "evaluated_windows": 0}
    y_true, y_pred = known.ground_truth.astype(int), known.predicted_anomaly.astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    result = {"dataset": name, "evaluated_windows": len(known), "accuracy": accuracy_score(y_true, y_pred), "precision": precision_score(y_true, y_pred, zero_division=0), "recall": recall_score(y_true, y_pred, zero_division=0), "f1": f1_score(y_true, y_pred, zero_division=0), "false_positive_rate": fp / (fp + tn) if fp + tn else np.nan, "false_alarm_rate": fp / len(known), "tn": tn, "fp": fp, "fn": fn, "tp": tp}
    if y_true.nunique() == 2:
        result["roc_auc"] = roc_auc_score(y_true, known.reconstruction_error)
        result["pr_auc"] = average_precision_score(y_true, known.reconstruction_error)
    return result


def event_metrics(predicted_events: pd.DataFrame, truth_windows: pd.DataFrame) -> dict:
    truth = truth_windows[truth_windows.ground_truth_known & truth_windows.ground_truth.eq(1)]
    # Event overlap matching, one predicted event can match one true event in its recording/segment.
    true_events = group_truth_events(truth)
    # Greedy one-to-one overlap matching: a true event is credited at most once.
    # This prevents event recall from ever exceeding 1.0 when detection fragments
    # one ground-truth event into several predicted events.
    matched_truth_indices: set[int] = set()
    for _, event in predicted_events.iterrows():
        candidate = true_events[(true_events.recording == event.recording) & (true_events.segment_id == event.segment_id) & (true_events.start_time <= event.end_time) & (true_events.end_time >= event.start_time)]
        unmatched = [index for index in candidate.index if index not in matched_truth_indices]
        if unmatched:
            matched_truth_indices.add(unmatched[0])
    matches = len(matched_truth_indices)
    precision = matches / len(predicted_events) if len(predicted_events) else 0.0
    recall = matches / len(true_events) if len(true_events) else 0.0
    return {"true_events": len(true_events), "predicted_events": len(predicted_events), "matched_events": matches, "event_precision": precision, "event_recall": recall, "event_f1": 2 * precision * recall / (precision + recall) if precision + recall else 0.0}


def group_truth_events(frame: pd.DataFrame) -> pd.DataFrame:
    output = []
    for (recording, segment_id), group in frame.groupby(["recording", "segment_id"]):
        groups = group.ground_truth.ne(group.ground_truth.shift(fill_value=0)).cumsum()
        for _, block in group.groupby(groups):
            if int(block.ground_truth.iloc[0]):
                output.append({"recording": recording, "segment_id": segment_id, "start_time": block.start_time.iloc[0], "end_time": block.end_time.iloc[-1]})
    return pd.DataFrame(output)
