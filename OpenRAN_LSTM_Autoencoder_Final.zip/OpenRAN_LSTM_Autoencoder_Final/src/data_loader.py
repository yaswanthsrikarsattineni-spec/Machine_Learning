"""Discover recordings and create the fixed recording-level baseline split."""
from __future__ import annotations

import logging
import zipfile
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

LOGGER = logging.getLogger(__name__)


def baseline_metadata(baseline_dir: Path) -> pd.DataFrame:
    rows = []
    for path in sorted(baseline_dir.rglob("*.zip")):
        rows.append({"recording": path.stem, "scenario": path.parent.name, "path": str(path)})
    frame = pd.DataFrame(rows)
    if len(frame) != 57:
        raise ValueError(f"Expected 57 baseline ZIP recordings, found {len(frame)}")
    expected = {"1UE": 35, "5UE": 20, "7UE-Ping": 2}
    if frame.scenario.value_counts().to_dict() != expected:
        raise ValueError(f"Unexpected baseline scenario counts: {frame.scenario.value_counts().to_dict()}")
    return frame


def make_baseline_split(metadata: pd.DataFrame, seed: int) -> pd.DataFrame:
    """Reproduce the notebook's 40/8/9 split, preserving recording boundaries."""
    ping = metadata.query("scenario == '7UE-Ping'")
    main = metadata.query("scenario != '7UE-Ping'")
    ping_train = ping.sample(n=1, random_state=seed)
    ping_test = ping.drop(ping_train.index)
    main_train, main_temp = train_test_split(main, test_size=16, stratify=main["scenario"], random_state=seed)
    main_val, main_test = train_test_split(main_temp, test_size=8, stratify=main_temp["scenario"], random_state=seed)
    parts = [main_train.assign(split="train"), ping_train.assign(split="train"), main_val.assign(split="validation"), main_test.assign(split="normal_test"), ping_test.assign(split="normal_test")]
    result = pd.concat(parts, ignore_index=True).sample(frac=1, random_state=seed).reset_index(drop=True)
    expected = {"train": 40, "validation": 8, "normal_test": 9}
    if result.split.value_counts().to_dict() != expected or result.recording.nunique() != 57:
        raise AssertionError("Invalid baseline split")
    return result


def anomaly_metadata(anomaly_dir: Path) -> pd.DataFrame:
    rows = []
    for path in sorted(anomaly_dir.rglob("radio.csv")):
        relative = path.relative_to(anomaly_dir)
        scenario = relative.parts[0]
        recording = "/".join(relative.parts[:-1])
        rows.append({"recording": recording, "scenario": scenario, "path": str(path), "split": "anomaly_test"})
    frame = pd.DataFrame(rows)
    if len(frame) != 16:
        raise ValueError(f"Expected 16 anomaly radio recordings, found {len(frame)}")
    return frame


def read_radio(path: str | Path, baseline_zip: bool) -> pd.DataFrame:
    path = Path(path)
    try:
        if baseline_zip:
            with zipfile.ZipFile(path) as archive:
                with archive.open("radio.csv") as source:
                    return pd.read_csv(source)
        return pd.read_csv(path)
    except (OSError, zipfile.BadZipFile, KeyError) as exc:
        raise RuntimeError(f"Unable to read radio recording {path}: {exc}") from exc
