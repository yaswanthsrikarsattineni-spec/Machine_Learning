"""Create windows only within one recording's usable continuous segments."""
from __future__ import annotations

import numpy as np
import pandas as pd


def create_windows(segments: list[pd.DataFrame], features: list[str], window_size: int, step_size: int, recording: str, scenario: str, include_labels: bool, anomaly_label_fraction: float = 0.5) -> tuple[np.ndarray, pd.DataFrame]:
    windows, metadata = [], []
    for segment_id, segment in enumerate(segments):
        for start in range(0, len(segment) - window_size + 1, step_size):
            end = start + window_size
            block = segment.iloc[start:end]
            windows.append(block[features].to_numpy(dtype=np.float32))
            labels = block.anomaly if include_labels else pd.Series(dtype=float)
            # Baseline recordings are established normal; anomaly windows are evaluated
            # only if every source row has a known label.
            known = bool(labels.notna().all()) if include_labels else True
            truth = int(labels.mean() >= anomaly_label_fraction) if include_labels and known else (0 if not include_labels else np.nan)
            metadata.append({"recording": recording, "scenario": scenario, "segment_id": segment_id, "start_time": float(block.time_seconds.iloc[0]), "end_time": float(block.time_seconds.iloc[-1]), "ground_truth": truth, "ground_truth_known": known})
    shape = (0, window_size, len(features)) if not windows else None
    return np.empty(shape, dtype=np.float32) if not windows else np.stack(windows), pd.DataFrame(metadata)
