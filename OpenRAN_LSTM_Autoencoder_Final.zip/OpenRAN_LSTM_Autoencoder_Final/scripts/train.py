"""Compatibility entry point for the full training pipeline."""
from run_pipeline import main
if __name__ == "__main__": main()
