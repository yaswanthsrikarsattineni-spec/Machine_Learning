"""Compatibility entry point for the full evaluation pipeline."""
from run_pipeline import main
if __name__ == "__main__": main()
