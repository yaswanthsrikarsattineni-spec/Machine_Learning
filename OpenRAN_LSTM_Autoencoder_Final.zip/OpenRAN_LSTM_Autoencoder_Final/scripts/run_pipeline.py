"""Run the complete leakage-safe Open RAN LSTM autoencoder experiment.

Run from the project root: .venv\\Scripts\\python scripts\\run_pipeline.py
Use --smoke for a one-epoch execution check without changing the fixed split.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import joblib
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

from src.data_loader import anomaly_metadata, baseline_metadata, make_baseline_split, read_radio
from src.detection import attach_predictions, group_events, label_persistence
from src.evaluation import detection_metrics, event_metrics
from src.model import build_autoencoder, reconstruction_errors
from src.preprocessing import preprocess_radio
from src.threshold import analyze_thresholds
from src.utils import configure_logging, ensure_output_dirs, load_config, save_json, set_reproducibility
from src.visualization import save_error_plot, save_timeline, save_training_plot
from src.windowing import create_windows

LOGGER = logging.getLogger(__name__)


def load_split_windows(rows: pd.DataFrame, config: dict, include_labels: bool) -> tuple[np.ndarray, pd.DataFrame, pd.DataFrame, list[np.ndarray]]:
    """Preprocess and window each recording individually; raw data is never mutated."""
    arrays, metadata, summaries, fit_rows = [], [], [], []
    features, settings, windowing = config["features"], config["preprocessing"], config["windowing"]
    for row in rows.itertuples(index=False):
        raw = read_radio(row.path, baseline_zip=(getattr(row, "split") != "anomaly_test"))
        processed = preprocess_radio(raw, features, settings, row.recording, row.scenario, include_labels)
        summaries.append({**processed.statistics, "split": row.split})
        windows, info = create_windows(processed.segments, features, windowing["window_size"], windowing["step_size"], row.recording, row.scenario, include_labels, windowing["anomaly_label_fraction"])
        if len(windows):
            arrays.append(windows); metadata.append(info)
        fit_rows.extend([segment[features].to_numpy() for segment in processed.segments])
    shape = (0, windowing["window_size"], len(features))
    return (np.concatenate(arrays) if arrays else np.empty(shape, dtype=np.float32), pd.concat(metadata, ignore_index=True) if metadata else pd.DataFrame(), pd.DataFrame(summaries), fit_rows)


def scale_windows(windows: np.ndarray, scaler: StandardScaler) -> np.ndarray:
    if not len(windows): return windows
    return scaler.transform(windows.reshape(-1, windows.shape[-1])).reshape(windows.shape).astype(np.float32)


def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--smoke", action="store_true", help="Run one epoch with capped training windows for execution verification."); args = parser.parse_args()
    configure_logging(); config = load_config(); ensure_output_dirs(config); set_reproducibility(config["seed"])
    tables, figures, predictions_dir, models = (config["paths"]["results_dir"] / "tables", config["paths"]["results_dir"] / "figures", config["paths"]["results_dir"] / "predictions", config["paths"]["models_dir"])
    baseline = make_baseline_split(baseline_metadata(config["paths"]["baseline_dir"]), config["seed"])
    anomalies = anomaly_metadata(config["paths"]["anomaly_dir"])
    baseline[["recording", "scenario", "split"]].to_csv(tables / "recording_split.csv", index=False)
    LOGGER.info("Dataset detected: %d baseline, %d anomaly recordings", len(baseline), len(anomalies))
    groups = {name: frame for name, frame in baseline.groupby("split")}
    train_raw, train_info, train_stats, fit_rows = load_split_windows(groups["train"], config, False)
    val_raw, val_info, val_stats, _ = load_split_windows(groups["validation"], config, False)
    normal_raw, normal_info, normal_stats, _ = load_split_windows(groups["normal_test"], config, False)
    anomaly_raw, anomaly_info, anomaly_stats, _ = load_split_windows(anomalies, config, True)
    preprocessing_summary = pd.concat([train_stats, val_stats, normal_stats, anomaly_stats], ignore_index=True)
    preprocessing_summary.to_csv(tables / "preprocessing_summary.csv", index=False)
    if not fit_rows: raise RuntimeError("No usable training rows after preprocessing")
    scaler = StandardScaler().fit(np.concatenate(fit_rows))  # training rows only
    joblib.dump(scaler, models / "scaler.joblib")
    train, validation, normal_test, anomaly_test = [scale_windows(x, scaler) for x in (train_raw, val_raw, normal_raw, anomaly_raw)]
    if not len(train) or not len(validation): raise RuntimeError("Training/validation window generation produced no windows")
    LOGGER.info("Window shapes: train=%s validation=%s normal_test=%s anomaly=%s", train.shape, validation.shape, normal_test.shape, anomaly_test.shape)
    model = build_autoencoder(config["windowing"]["window_size"], len(config["features"]), config["model"])
    callbacks = [tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=config["model"]["early_stopping_patience"], restore_best_weights=True), tf.keras.callbacks.ModelCheckpoint(models / "lstm_autoencoder.keras", monitor="val_loss", save_best_only=True), tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", patience=5)]
    training_x = train[: min(len(train), 2048)] if args.smoke else train
    epochs = 1 if args.smoke else config["model"]["epochs"]
    history = model.fit(training_x, training_x, validation_data=(validation, validation), epochs=epochs, batch_size=config["model"]["batch_size"], callbacks=callbacks, verbose=2)
    history_df = pd.DataFrame(history.history); history_df.index.name = "epoch"; history_df.reset_index().to_csv(tables / "training_history.csv", index=False); save_training_plot(history_df.reset_index(), figures / "training_history.png")
    val_errors = reconstruction_errors(model, validation, config["model"]["batch_size"]); normal_errors = reconstruction_errors(model, normal_test, config["model"]["batch_size"]); anomaly_errors = reconstruction_errors(model, anomaly_test, config["model"]["batch_size"])
    threshold_table, _ = analyze_thresholds(val_errors, config["threshold"]["candidate_percentiles"], normal_errors)
    selected = config["threshold"]["selected_percentile"]
    threshold = float(threshold_table.loc[threshold_table.percentile.eq(selected), "threshold"].iloc[0])
    validation_pred = attach_predictions(val_info, val_errors, threshold); normal_pred = attach_predictions(normal_info, normal_errors, threshold); anomaly_pred = attach_predictions(anomaly_info, anomaly_errors, threshold)
    # Add anomaly-label metrics to threshold sensitivity strictly after threshold candidates are derived from validation.
    for idx, candidate in threshold_table.iterrows():
        candidate_pred = attach_predictions(anomaly_info, anomaly_errors, candidate.threshold)
        candidate_metrics = detection_metrics(candidate_pred, "anomaly_test")
        for key in ("precision", "recall", "f1"): threshold_table.loc[idx, f"anomaly_{key}"] = candidate_metrics.get(key, np.nan)
    threshold_table.to_csv(tables / "threshold_analysis.csv", index=False)
    save_json({"method": "validation_percentile", "percentile": selected, "threshold": threshold, "validation_statistics": {"count": len(val_errors), "mean": float(val_errors.mean()), "std": float(val_errors.std())}}, models / "threshold.json")
    all_predictions = pd.concat([validation_pred.assign(dataset="validation"), normal_pred.assign(dataset="normal_test"), anomaly_pred.assign(dataset="anomaly_test")], ignore_index=True)
    all_predictions.to_csv(predictions_dir / "window_predictions.csv", index=False)
    detected_events = group_events(anomaly_pred, "anomaly_test")
    persistence_rows = []
    for candidate in config["persistence"]["candidate_window_counts"]:
        labelled = label_persistence(detected_events, candidate)
        persistence_rows.append({"persistence_windows": candidate, "approx_duration_seconds": candidate * config["windowing"]["window_size"] * 0.15, "detected_transient_events": int((labelled.predicted_event_type == "transient").sum()), "detected_persistent_events": int((labelled.predicted_event_type == "persistent").sum())})
    persistence_table = pd.DataFrame(persistence_rows); persistence_table.to_csv(tables / "persistence_threshold_analysis.csv", index=False)
    persistence_threshold = config["persistence"]["selected_window_count"]
    final_events = label_persistence(detected_events, persistence_threshold); final_events.to_csv(predictions_dir / "detected_events.csv", index=False)
    metrics = [detection_metrics(validation_pred, "validation_normal"), detection_metrics(normal_pred, "normal_test"), detection_metrics(anomaly_pred, "anomaly_test")]
    metrics_df = pd.DataFrame(metrics); metrics_df.to_csv(tables / "metrics_overall.csv", index=False)
    by_scenario = pd.DataFrame([detection_metrics(group, f"anomaly_{scenario}") for scenario, group in anomaly_pred.groupby("scenario")]); by_scenario.to_csv(tables / "metrics_by_scenario.csv", index=False)
    event_result = event_metrics(final_events, anomaly_pred); pd.DataFrame([event_result]).to_csv(tables / "event_metrics.csv", index=False)
    # Unlabelled records are excluded by detection_metrics; record this policy in final output.
    save_error_plot(validation_pred, threshold, "Validation reconstruction-error distribution", figures / "validation_error_distribution.png"); save_error_plot(normal_pred, threshold, "Unseen normal-test reconstruction-error distribution", figures / "normal_test_error_distribution.png"); save_error_plot(anomaly_pred, threshold, "Anomaly-test reconstruction-error distribution", figures / "anomaly_error_distribution.png"); save_timeline(anomaly_pred, figures / "anomaly_timeline.png")
    final_summary = {"dataset_statistics": {"baseline_recordings": len(baseline), "anomaly_recordings": len(anomalies)}, "split_statistics": baseline.split.value_counts().to_dict(), "feature_list": config["features"], "preprocessing_settings": config["preprocessing"], "window_settings": config["windowing"], "model_architecture": config["model"], "training_settings": {"smoke_run": args.smoke, "epochs_completed": len(history_df)}, "threshold": threshold, "persistence_threshold_windows": persistence_threshold, "persistence_rationale": config["persistence"]["rationale"], "normal_test_metrics": metrics[1], "anomaly_test_metrics": metrics[2], "event_metrics": event_result, "unknown_anomaly_label_policy": "Windows containing any missing row label are excluded from supervised metrics."}
    save_json(final_summary, config["paths"]["results_dir"] / "final_results.json")
    LOGGER.info("Complete. Threshold=%.6g | normal false alarm rate=%s | anomaly F1=%s", threshold, metrics[1].get("false_alarm_rate"), metrics[2].get("f1"))


if __name__ == "__main__": main()
