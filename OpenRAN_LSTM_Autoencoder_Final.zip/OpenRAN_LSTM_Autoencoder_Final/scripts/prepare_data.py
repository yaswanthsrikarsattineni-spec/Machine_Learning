"""Validate discovery/split and run preprocessing without model training."""
from run_pipeline import main
if __name__ == "__main__": main()
