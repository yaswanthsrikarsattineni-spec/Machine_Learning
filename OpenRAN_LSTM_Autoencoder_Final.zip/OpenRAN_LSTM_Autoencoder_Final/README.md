# LSTM Autoencoder-Based Persistent and Transient Anomaly Classification in Open RAN KPIs

This project is a reproducible, recording-level experiment for unsupervised anomaly detection in Open RAN Radio KPIs. An LSTM autoencoder learns only from normal Baseline recordings, scores reconstruction error on unseen data, and derives one global threshold exclusively from normal validation recordings.

## Data and split

Raw data remains immutable in `data/raw/`. The model consumes only `radio.csv` from 57 Baseline ZIP recordings and 16 anomaly recordings; it never mixes platform features with radio features. The deterministic `random_state=42` recording-level split is 40 train (25 1UE, 14 5UE, 1 7UE-Ping), 8 validation (5 1UE, 3 5UE), and 9 normal test (5 1UE, 3 5UE, 1 7UE-Ping). `results/tables/recording_split.csv` records the exact membership.

The exact 12 model features are `l1_pusch_count`, `l1_avg_pusch_count`, `l1_avg_UL_prbSize`, `l1_avg_UL_mcs`, `l1_avg_UL_tbs`, `l1_UL_tx`, `l1_ULMcsMin`, `l1_ULMcsMax`, `l1_ULTbsMax`, `l1_ULTbsMin`, `l1_ULPrbMax`, and `l1_ULPrbMin`. Timestamp, anomaly labels, index columns, and platform features are excluded from model inputs. These KPIs were selected in the preserved inspection notebook for availability and variation.

## Methodology

Each recording is independently sorted, deduplicated (first exact timestamp retained and reported), parsed as absolute time or, for `Anomaly/RADIO/radio.csv`, elapsed duration. Major timestamp discontinuities form separate segments. Short missing blocks (at most 10 rows) are time-interpolated; long blocks are excluded and never bridged. Windows are 20 samples × 12 features (about 3 seconds) with step 1 and cannot cross a recording, gap, or segment boundary.

`StandardScaler` is fit exclusively on usable training rows and saved to `models/scaler.joblib`. The configurable Keras architecture is 64/32 LSTM encoder, repeat vector, 32/64 LSTM decoder, and time-distributed dense output. It uses MSE, validation early stopping, and a best-model checkpoint. Window MSE is thresholded using validation-only percentiles (95/97/99); the selected 95th-percentile threshold is saved in `models/threshold.json`.

Anomaly windows are ground-truth positive when at least the configurable 50% of known row labels are anomalous. Windows containing any missing label are explicitly excluded from supervised metrics, never silently set normal. Predicted windows are grouped only within a recording/segment. Persistence candidates (1–5 windows) are tabled; the configured primary 3-window (~9 second) criterion and its rationale are recorded separately from anomaly detection.

## Run

Use the existing Python 3.13 virtual environment from the project root:

```powershell
.venv\Scripts\python scripts\run_pipeline.py
```

For an execution-only one-epoch check:

```powershell
.venv\Scripts\python scripts\run_pipeline.py --smoke
```

The pipeline writes models to `models/`, figures to `results/figures/`, tables to `results/tables/`, predictions to `results/predictions/`, and a machine-readable summary to `results/final_results.json`. `config/config.yaml` centralizes paths, features, leakage-sensitive preprocessing settings, windowing, model hyperparameters, threshold candidates, and persistence candidates.

## Limitations

The threshold is intentionally chosen without anomaly labels, so detection quality depends on how representative normal validation recordings are. Persistence is duration-based after detection; it is not a second learned classifier. The final report records excluded unknown-label windows and must be interpreted alongside class imbalance, event matching, and scenario-specific results.
